package com.cg.mypaymentapp.Exception;

public class ZeroBalanceException  extends RuntimeException
{

	public ZeroBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ZeroBalanceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ZeroBalanceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ZeroBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ZeroBalanceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
	
}
